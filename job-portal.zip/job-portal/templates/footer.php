</div>
<!-- footer -->
<footer class="footer-container row justify-content-center mt-4 py-3">
	<div class="text-white">Copyright 2022 Sali Saliev Job Portal</div>
</footer>
<script src="<?php echo $server; ?>js/save.js"></script>
<script src="<?php echo $server; ?>js/search.js"></script>
</body>
</html>